#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ZigBee.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "UserGpio.h"
#include "oled.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "queue.h"
#include "ls1x_clock.h"
#include "ls1c102_adc.h"

#define LED 20
#define R0 		58769

char str[50];
static uint16_t temperature;
static uint16_t humidity;
static uint16_t gas;
uint8_t received_data = 0;
uint8_t data[9];
uint8_t Read_Buffer[255]; // 设置接收缓冲数组
uint8_t Read_length;
int cvalue = 1200;
int main(int arg, char *args[])
{
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    
    EnableInt(); // 开总中断
    DL_LN3X_Init(DL_LN3X_NODE,CHANNEL,Network1_Id);//设置为主机（接收端），设置信道为0x12，网络地址为0x0003
    Queue_Init(&Circular_queue);
    BEEP_Init();
    
    DHT11_Init();                               // DHT11初始化  
    AFIO_RemapConfig(AFIOB, GPIO_Pin_17, 0);        // 初始化ADC通道4引脚
    Adc_powerOn();                                  // 打开ADC电源
    Adc_open(ADC_CHANNEL_I7);                       // 开启ADC通道4 
    while (1)
    {
        uint32_t adcx_temp,vol,temp;
	    uint32_t Rs;

        sprintf(str, "温度: %2d ℃", temperature / 10);
        OLED_Show_Str(5, 4, str, 16);    // OLED显示界面
        sprintf(str, "湿度: %2d %%RH", humidity / 10);
        OLED_Show_Str(5, 6, str, 16);    // OLED显示界面
        sprintf(str, "瓦斯浓度:%2d ppm", gas);
        OLED_Show_Str(5, 0, str, 16);     // OLED显示界面

        DHT11_Read_Data(&temperature, &humidity);//温湿度采集
        adcx_temp=Adc_Measure(ADC_CHANNEL_I7);   //ADC数据采集
        vol=adcx_temp*1000/Adc_Measure(ADC_CHANNEL_1V);
	    Rs = 50000000/vol-20000;								//电压计算电阻值
	    temp =610*R0*R0/Rs;										//计算rs/r0比值	
        gas=temp/Rs-6;
        data[0]=125;
        data[1] = temperature / 256;
        data[2] = temperature % 256;
        data[3] = humidity / 256;
        data[4] = humidity % 256;
        data[5] = gas;   //数据存入云数据包
        DL_LN3X_Send(data, 9, ZIGBEE_RX_NODE);
                if(gas>10)
       {
        gpio_write_pin(GPIO_PIN_36, 1); // 将GPIO_PIN_20引脚设置为高电平
        delay_ms(100);                  // 延迟100毫秒
        } 
                        if(gas<10)
       {
        gpio_write_pin(GPIO_PIN_36, 0); // 将GPIO_PIN_20引脚设置为高电平
        delay_ms(100);                  // 延迟100毫秒
        } 
        //风扇控制
    }
    return 0;
}
