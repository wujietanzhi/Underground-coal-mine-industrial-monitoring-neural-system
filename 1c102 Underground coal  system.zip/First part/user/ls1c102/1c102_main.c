#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ZigBee.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "UserGpio.h"
#include "oled.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "queue.h"
#include "ls1x_clock.h"
#include "ls1c102_adc.h"

#define LED 20
char str[100];
static uint16_t gas;
static uint16_t dust;
uint8_t received_data = 0;
uint8_t data[6];
uint8_t Read_Buffer[255]; // 设置接收缓冲数组
uint8_t Read_length;
uint16_t adc_value = 0;
int32_t vol = 0,i=0;
int pwm_cmp = 1;

int main(int arg, char *args[])
{
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    EnableInt(); // 开总中断
    Queue_Init(&Circular_queue);
    BEEP_Init();
    AFIO_RemapConfig(AFIOB, GPIO_Pin_14, 0);        // 初始化ADC通道4引脚                 
    Adc_powerOn(); //打开ADC电源
    Adc_open(ADC_CHANNEL_I4); 
    DL_LN3X_Init(DL_LN3X_NODE,CHANNEL,Network1_Id);//设置为从机，设置信道为0x12，网络地址为0x0005
    while (1)
    {
        
    adc_value = 0;
	for(i=0;i<5;i++)
	{
		TIM_SetCompare1(13, pwm_cmp);      // 设置TIM1通道1的比较值为pwm_cmp
        pwm_cmp += 1;                      // 增加pwm_cmp的值
        if (pwm_cmp > 20)
        pwm_cmp = 1;
		gpio_write_pin(GPIO_PIN_15, 1);
		delay_us(280);
		adc_value = Adc_Measure(ADC_CHANNEL_I4);
		delay_us(40);
		gpio_write_pin(GPIO_PIN_15, 0);
		//获得电压值（X2是由于电路分压）
		vol =vol+ adc_value * 3300 / 4096 * 2;
		delay_ms(10);//至少等待10ms才能下次采集
	}
	    vol = vol / 5;//均值计算
        dust = (( vol + 1 ) *163/100 - 127)/20;//电压值转换为粉尘浓度值
        //sprintf(str, "%4d",adc_value);       
        OLED_Show_Str(10, 0, "粉尘浓度", 16);      // OLED显示界面
        OLED_Show_Str(15, 4, "      ppm", 16);
		OLED_Show_Str(25, 4, str, 16); 
        delay_ms(5);
		data[0]=250;
        data[1] = dust / 256;
        data[2] = dust % 256;
		sprintf(str, "%4d",dust); 
        DL_LN3X_Send(data, 6, ZIGBEE_RX_NODE);
    }

    return 0;
}
