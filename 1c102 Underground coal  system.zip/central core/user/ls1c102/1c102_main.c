#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ZigBee.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "UserGpio.h"
#include "oled.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "queue.h"
#include "ls1x_clock.h"
#include "ls1c102_ptimer.h"
#include "esp8266.h"
#define LED 20

char str[50];
static uint16_t temp;
static uint16_t humi;
static uint16_t dust;
static uint16_t gas;
uint8_t received_data = 0;
uint8_t Read_Buffer[255]; // 设置接收缓冲数组
uint8_t Read_length;
uint8_t da = 0;
int danger,tempdanger,humidanger,gasdanger,dustdanger;
uint8_t data[8] = {0x55, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBB}; //温湿度数据上云平台    数据包
int pwm_cmp = 1;

int main(int arg, char *args[])
{
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    Uart1_init(9600);
    BEEP_Init();
    EnableInt(); // 开总中断
    DL_LN3X_Init(DL_LN3X_NODE, CHANNEL, Network1_Id);
    Queue_Init(&Circular_queue);
    while (1)
    {
           Read_length = Queue_HadUse(&Circular_queue);           // 返回队列中数据的长度
           Queue_Read(&Circular_queue, Read_Buffer, Read_length);
           if(Read_Buffer[6]==125)
            {  // 读取队列缓冲区的值到接收缓冲区
            temp = Read_Buffer[7] << 8 | Read_Buffer[8];
            humi = Read_Buffer[9] << 8 | Read_Buffer[10];
            gas = Read_Buffer[11];
            }

            if(Read_Buffer[6]==250)
            { 
            dust=Read_Buffer[7] << 8 | Read_Buffer[8];
            }  //Zigbee数据包解析
        sprintf(str, "温度: %2d ℃", temp / 10);
        OLED_Show_Str(5,0, str, 16);    // OLED显示界面
        sprintf(str, "湿度: %2d %%RH", humi / 10);
        OLED_Show_Str(5, 3, str, 16);    // OLED显示界面
        sprintf(str, "瓦斯浓度:%2d ppm", gas);
        OLED_Show_Str(5, 6, str, 16);     // OLED显示界面
        sprintf(str, "粉尘浓度:%2d ppm", gas);
        OLED_Show_Str(5, 9, str, 16);     // OLED显示界面
            if(temp<=30)
            {
                tempdanger=25;
            }
            if(temp>=30)
            {
                tempdanger=50;
            }
            if(humi<=70)
            {
                humidanger=25;
            }
            if(temp>=80)
            {
                humidanger=50;
            }
            if(gas<=10)
            {
                gasdanger=25;
            }
            if(gas>=10)
            {
                gasdanger=50;
            }
            if(dust<=50)
            {
                dustdanger=25;
            }
            if(dust>=50)
            {
                dustdanger=50;
            }
            danger=tempdanger*humidanger/100*gasdanger/100*dustdanger/100;//报警阈值计算
            if(danger<3)
            {
                BEEP_OFF;
            }
            if(danger>=3)
            {
                BEEP_ON;
            }             //阈值报警
            data[2] =temp/10;    
            data[3] =humi/10;
            data[4] =gas;
            data[5] =dust;
            data[6]=danger; //将数据放入云平台数据包中
            delay_ms(500);
            UART_SendDataALL(UART1, data, 8);
    }
}